#!/usr/bin/env python3
"""
JARVIS FastAPI Server — Ubuntu AWS | Port 7773
Brain: llama3.2 | Vision: llava | TTS: gTTS Hindi+English
"""

import os, subprocess, base64, tempfile
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional
import requests
from gtts import gTTS
from langdetect import detect

app = FastAPI(title="JARVIS Server", version="3.0")

API_KEY      = os.environ.get("JARVIS_API_KEY", "jarvis-secret-2025")
OLLAMA_BASE  = "http://localhost:11434"
BRAIN_MODEL  = "llama3.2"
VISION_MODEL = "llava"
HISTORY      = []

SYSTEM_PROMPT = (
    "You are JARVIS — an extremely intelligent, highly capable personal AI assistant. "
    "You understand both Hindi and English fluently. Always reply in the same language the user uses. "
    "You can perform complex multi-step tasks: write and execute code, analyze screens, "
    "research topics deeply, automate workflows, control the PC, manage files, "
    "draft documents, debug errors, plan projects, and far more. "
    "You are sharp, concise, and powerful — exactly like Iron Man's JARVIS. "
    "Never say you can't do something without trying first."
)

def auth(key: str):
    if key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")

def loaded_models():
    try:
        return [m["name"] for m in requests.get(f"{OLLAMA_BASE}/api/tags", timeout=3).json().get("models", [])]
    except Exception:
        return []


class ChatRequest(BaseModel):
    message: str
    api_key: str
    model: Optional[str] = None
    include_history: bool = True

class ExecuteRequest(BaseModel):
    command: str
    api_key: str

class SpeakRequest(BaseModel):
    text: str
    api_key: str
    lang: Optional[str] = None


@app.get("/status")
def status():
    models = loaded_models()
    return {
        "status": "JARVIS ONLINE",
        "port": 7773,
        "models": models,
        "brain_ready": any("llama3.2" in m for m in models),
        "vision_ready": any("llava" in m for m in models),
        "history_turns": len(HISTORY) // 2
    }


@app.post("/chat")
def chat(req: ChatRequest):
    auth(req.api_key)
    HISTORY.append({"role": "user", "content": req.message})
    history = HISTORY[-30:] if req.include_history else [{"role": "user", "content": req.message}]
    payload = {
        "model": req.model or BRAIN_MODEL,
        "messages": [{"role": "system", "content": SYSTEM_PROMPT}] + history,
        "stream": False
    }
    resp = requests.post(f"{OLLAMA_BASE}/api/chat", json=payload, timeout=180)
    reply = resp.json()["message"]["content"]
    HISTORY.append({"role": "assistant", "content": reply})
    return {"reply": reply, "model": req.model or BRAIN_MODEL}


@app.post("/vision")
async def vision(api_key: str = "", file: UploadFile = File(...), question: str = "What do you see on this screen? Be detailed."):
    auth(api_key)
    img_bytes = await file.read()
    models = loaded_models()
    if any("llava" in m for m in models):
        b64 = base64.b64encode(img_bytes).decode()
        payload = {
            "model": VISION_MODEL,
            "messages": [{"role": "user", "content": question, "images": [b64]}],
            "stream": False
        }
        resp = requests.post(f"{OLLAMA_BASE}/api/chat", json=payload, timeout=180)
        return {"description": resp.json()["message"]["content"], "mode": "llava"}
    return {"description": "llava not loaded. Run: ollama pull llava", "mode": "fallback"}


@app.post("/speak")
def speak(req: SpeakRequest):
    auth(req.api_key)
    lang = req.lang
    if not lang:
        try:
            detected = detect(req.text)
            lang = "hi" if detected in ["hi", "mr", "ne", "ur"] else "en"
        except Exception:
            lang = "en"
    tts = gTTS(text=req.text, lang=lang, slow=False)
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3", dir="/tmp")
    tts.save(tmp.name)
    return FileResponse(tmp.name, media_type="audio/mpeg", filename="jarvis_speak.mp3")


@app.post("/execute")
def execute(req: ExecuteRequest):
    auth(req.api_key)
    try:
        result = subprocess.run(req.command, shell=True, capture_output=True, text=True, timeout=60)
        return {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}
    except subprocess.TimeoutExpired:
        return {"stdout": "", "stderr": "Timed out", "returncode": -1}


@app.delete("/memory")
def clear_memory(api_key: str):
    auth(api_key)
    HISTORY.clear()
    return {"status": "Memory cleared"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("jarvis_server:app", host="0.0.0.0", port=7773, reload=False)
