import subprocess, os, webbrowser

def _get_pyautogui():
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.3
        return pyautogui
    except Exception:
        return None

def _get_pyperclip():
    try:
        import pyperclip
        return pyperclip
    except Exception:
        return None

def open_app(app_name):
    subprocess.Popen(app_name, shell=True)
    return f"Opened {app_name}"

def open_url(url):
    if not url.startswith("http"):
        url = "https://" + url
    webbrowser.open(url)
    return f"Opened {url} in browser"

def type_text(text):
    pg = _get_pyautogui()
    if pg:
        pg.typewrite(text, interval=0.03)
    return f"Typed: {text}"

def press_key(key):
    pg = _get_pyautogui()
    if pg:
        pg.press(key)
    return f"Pressed key: {key}"

def hotkey(*keys):
    pg = _get_pyautogui()
    if pg:
        pg.hotkey(*keys)
    return "Hotkey: " + "+".join(keys)

def take_screenshot(path="./jarvis/outputs/screenshot.png"):
    pg = _get_pyautogui()
    if pg:
        pg.screenshot(path)
        return f"Screenshot saved: {path}"
    return "Screenshot requires display (run on your PC)"

def run_command(cmd):
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
        return result.stdout or result.stderr
    except subprocess.TimeoutExpired:
        return "Command timed out"

def copy_to_clipboard(text):
    pc = _get_pyperclip()
    if pc:
        pc.copy(text)
        return "Copied to clipboard"
    return "Clipboard not available in headless mode"

def get_clipboard():
    pc = _get_pyperclip()
    return pc.paste() if pc else ""

def create_file(path, content=""):
    with open(path, "w") as f:
        f.write(content)
    return f"File created: {path}"

def read_file(path):
    with open(path, "r") as f:
        return f.read()

def search_web(query):
    q = query.replace(" ", "+")
    url = "https://www.google.com/search?q=" + q
    webbrowser.open(url)
    return f"Searching: {query}"
