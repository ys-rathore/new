"""
JARVIS PC Client — v8.0
Connect karo apne AWS server se aur baat karo!
Hindi + English dono support hai.
"""

import requests, os, tempfile, sys, re, io
import speech_recognition as sr

# ╔══════════════════════════════════════════╗
# ║  APNA SERVER IP YAHAN DAALO             ║
SERVER_URL = "http://YOUR_SERVER_IP:7773"
API_KEY    = "jarvis-secret-2025"
# ╚══════════════════════════════════════════╝


def speak(text: str):
    """JARVIS ki awaaz — server se MP3 aata hai, PC pe bajta hai."""
    if not text.strip():
        return
    try:
        resp = requests.post(f"{SERVER_URL}/speak",
                             json={"text": text.strip(), "api_key": API_KEY},
                             timeout=20)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as f:
            f.write(resp.content)
            tmp = f.name
        if os.name == "nt":           # Windows
            os.system(f"start /wait {tmp}")
        elif "darwin" in sys.platform: # Mac
            os.system(f"afplay {tmp}")
        else:                          # Linux
            os.system(f"mpg123 -q {tmp} 2>/dev/null")
        os.remove(tmp)
    except Exception as e:
        print(f"[Speaker Error] {e}")


def chat(message: str) -> str:
    """Token-by-token streaming — pehla word ~1.5s mein aata hai!"""
    print("
JARVIS: ", end="", flush=True)
    buffer     = ""
    full_reply = ""
    # Sentence boundary detect karo toh turant speak karo
    sent_end = re.compile(r"(?<=[.!?।
])\s*")

    try:
        with requests.post(
            f"{SERVER_URL}/chat/stream",
            json={"message": message, "api_key": API_KEY},
            stream=True, timeout=120
        ) as resp:
            for chunk in resp.iter_content(chunk_size=None, decode_unicode=True):
                if chunk:
                    print(chunk, end="", flush=True)
                    buffer     += chunk
                    full_reply += chunk
                    parts = sent_end.split(buffer)
                    if len(parts) > 1:
                        for sentence in parts[:-1]:
                            if sentence.strip():
                                speak(sentence)
                        buffer = parts[-1]
        if buffer.strip():
            speak(buffer)
        print()
        return full_reply
    except Exception as e:
        print(f"
[Chat Error] {e}")
        return ""


def listen() -> str:
    """Mic se awaaz record karo."""
    recognizer = sr.Recognizer()
    recognizer.energy_threshold       = 300
    recognizer.dynamic_energy_threshold = True
    with sr.Microphone() as source:
        print("
🎙️  Bol rahe hain... (baat karo)")
        recognizer.adjust_for_ambient_noise(source, duration=0.3)
        audio = recognizer.listen(source, timeout=8, phrase_time_limit=15)
    try:
        text = recognizer.recognize_google(audio, language="hi-IN")
        print(f"[Aapne kaha] {text}")
        return text
    except Exception:
        return ""


def see_screen() -> str:
    """Screen ka screenshot server ko bhejo — JARVIS analyze karega."""
    try:
        import mss
        from PIL import Image
        with mss.mss() as sct:
            img = sct.grab(sct.monitors[0])
            pil = Image.frombytes("RGB", img.size, img.bgra, "raw", "BGRX")
            buf = io.BytesIO()
            pil.save(buf, format="PNG")
            buf.seek(0)
        resp = requests.post(
            f"{SERVER_URL}/vision",
            data={"api_key": API_KEY},
            files={"file": ("screen.png", buf, "image/png")},
            timeout=60
        )
        return resp.json().get("description", "")
    except Exception as e:
        return f"Screen error: {e}"


def main():
    print("=" * 55)
    print("      🤖  JARVIS — Aapka Personal AI Assistant")
    print(f"      Server: {SERVER_URL}")
    print("=" * 55)

    # Server check
    try:
        s = requests.get(f"{SERVER_URL}/status", timeout=5).json()
        print(f"✅ {s['status']} | Model: {s['active_model']} | Vision: {s['vision']}")
    except Exception:
        print("❌ Server se connect nahi ho pa raha!")
        print(f"   Check karo: {SERVER_URL}")
        return

    speak("Namaste Sir! JARVIS ready hai. Aap Hindi ya English mein baat kar sakte hain.")

    mode = input("
Kaise baat karein? [voice / text]: ").strip().lower()

    while True:
        try:
            if mode == "voice":
                user_input = listen()
                if not user_input:
                    continue
            else:
                user_input = input("
Aap: ").strip()
                if not user_input:
                    continue

            # Exit commands
            if user_input.lower() in ["exit", "quit", "bye", "band karo", "alvida"]:
                speak("Alvida Sir. JARVIS offline ho raha hai.")
                break

            # Screen analysis
            if any(w in user_input.lower() for w in ["screen", "dekho", "kya dikh raha", "analyze"]):
                print("🖥️  Screen dekh raha hoon...")
                desc = see_screen()
                chat(f"User ne kaha: {user_input}
Screen pe yeh dikh raha hai: {desc}
Help karo.")
            else:
                chat(user_input)

        except KeyboardInterrupt:
            speak("Goodbye Sir.")
            break

if __name__ == "__main__":
    main()
