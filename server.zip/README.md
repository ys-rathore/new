# JARVIS Server — AWS Ubuntu

## Files
- jarvis_server.py  → FastAPI server (port 7773)
- setup.sh          → One-time install script

## Deploy Steps

### 1. Upload to server
```
scp server.zip ubuntu@<YOUR_IP>:~/
ssh ubuntu@<YOUR_IP>
unzip server.zip -d ~/jarvis-server
cd ~/jarvis-server
```

### 2. Install everything
```
chmod +x setup.sh
sudo bash setup.sh
```

### 3. Start JARVIS server
```
nohup sudo /opt/jarvis-env/bin/uvicorn jarvis_server:app --host 0.0.0.0 --port 7773 > nohup.out 2>&1 &
```

### 4. Test
```
curl http://127.0.0.1:7773/status
```

## API Key
Default: jarvis-secret-2025
Change via env: export JARVIS_API_KEY=your_new_key
