#!/bin/bash
set -e
echo "=== JARVIS Turbo Setup for m7i-flex.large (AVX-512) ==="

apt-get update -y
apt-get install -y python3 python3-pip python3-venv curl git screen htop

# Verify AVX-512 support (m7i has it!)
grep -o 'avx512[^ ]*' /proc/cpuinfo | sort -u | head -5
echo "✅ AVX-512 confirmed — Ollama will use it automatically!"

# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh
systemctl enable ollama
systemctl start ollama
sleep 5

# Pull ONLY llama3.2:1b (fastest, 636MB)
echo "Pulling llama3.2:1b (636MB only — fastest model)..."
ollama pull llama3.2:1b

# llava is optional (takes 4GB RAM on 4GB machine — risky)
# echo "Pulling llava (optional - needs ~4GB RAM)..."
# ollama pull llava

python3 -m venv /opt/jarvis-env
source /opt/jarvis-env/bin/activate
pip install --upgrade pip
sudo /opt/jarvis-env/bin/pip install fastapi uvicorn gtts langdetect requests pillow python-multipart

echo "=== Setup Complete! ==="
echo "Start: cd /home/ubuntu/jarvis/server && /opt/jarvis-env/bin/uvicorn jarvis_server:app --host 0.0.0.0 --port 7773"
