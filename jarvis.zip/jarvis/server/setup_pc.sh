#!/bin/bash
# JARVIS PC Setup — Ubuntu 24.04+ (one-time)
set -e
echo "=== JARVIS PC Setup v9.0 ==="

# portaudio for pyaudio
sudo apt install -y portaudio19-dev python3-venv python3-full mpg123 aplay

# Create venv
[ -d "$HOME/jarvis-env" ] && rm -rf ~/jarvis-env
python3 -m venv ~/jarvis-env
source ~/jarvis-env/bin/activate

pip install --upgrade pip
pip install requests SpeechRecognition pyaudio mss pillow

echo ""
echo "=== Setup Done! ==="
echo "Run JARVIS:"
echo "  source ~/jarvis-env/bin/activate"
echo "  python3 ~/Downloads/jarvis/server/jarvis_client.py"
