import ollama
from jarvis.memory.db import get_all_profile, get_recent_conversation, log_conversation

MODEL = "llama3.2"  # Change to any Ollama model: mistral, llama3, etc.

SYSTEM_PROMPT = """You are JARVIS, a hyper-intelligent personal AI assistant running locally.
You know everything about your user from your memory profile.
You speak Hindi and English fluently — respond in whichever language the user used.
You are direct, confident, witty and extremely capable. You can:
- Control the user's computer (files, apps, browser, code)
- Analyze and understand their screen
- Remember everything they tell you
- Execute complex multi-step tasks autonomously
- Search, write, calculate, code, research — anything
Never say you "can't" do something without trying every option first."""

def ask(user_input: str) -> str:
    profile = get_all_profile()
    history = get_recent_conversation(8)

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    if profile:
        profile_str = "\n".join(f"- {k}: {v}" for k,v in profile.items())
        messages.append({"role": "system", "content": f"User profile:\n{profile_str}"})

    for role, content in history:
        messages.append({"role": role, "content": content})

    messages.append({"role": "user", "content": user_input})

    log_conversation("user", user_input)
    response = ollama.chat(model=MODEL, messages=messages)
    reply = response["message"]["content"]
    log_conversation("assistant", reply)
    return reply
