"""
JARVIS PC Client — Connects to Ubuntu AWS Server on port 7773
Run this on your LOCAL PC only.
"""

import requests, os, tempfile
import speech_recognition as sr

SERVER_URL = "http://YOUR_UBUNTU_AWS_IP:7773"   # ← apna Ubuntu server IP yahan daalo
API_KEY    = "jarvis-secret-2025"               # ← server se match karna chahiye


def speak(text: str):
    try:
        resp = requests.post(f"{SERVER_URL}/speak",
                             json={"text": text, "api_key": API_KEY}, timeout=30)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as f:
            f.write(resp.content); tmp = f.name
        if os.name == "nt":
            os.system(f"start {tmp}")
        elif "darwin" in __import__("sys").platform:
            os.system(f"afplay {tmp}")
        else:
            os.system(f"mpg123 {tmp} 2>/dev/null || vlc {tmp} 2>/dev/null")
    except Exception as e:
        print(f"[Speaker] {e}")


def analyze_screen():
    try:
        import mss, io
        from PIL import Image
        with mss.mss() as sct:
            img = sct.grab(sct.monitors[0])
            pil = Image.frombytes("RGB", img.size, img.bgra, "raw", "BGRX")
            buf = io.BytesIO()
            pil.save(buf, format="PNG"); buf.seek(0)
        resp = requests.post(f"{SERVER_URL}/vision",
                             data={"api_key": API_KEY},
                             files={"file": ("screen.png", buf, "image/png")}, timeout=60)
        return resp.json().get("description", "")
    except Exception as e:
        return f"Screen error: {e}"


def chat(message: str) -> str:
    try:
        resp = requests.post(f"{SERVER_URL}/chat",
                             json={"message": message, "api_key": API_KEY}, timeout=180)
        return resp.json().get("reply", "")
    except Exception as e:
        return f"Server error: {e}"


def listen_once() -> str:
    recognizer = sr.Recognizer()
    recognizer.energy_threshold = 300
    recognizer.dynamic_energy_threshold = True
    with sr.Microphone() as source:
        print("🎙️  Listening...")
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        audio = recognizer.listen(source, timeout=8, phrase_time_limit=15)
    try:
        return recognizer.recognize_google(audio, language="hi-IN")
    except Exception:
        return ""


def run():
    print("=" * 55)
    print("    🤖  JARVIS — Ubuntu AWS Server")
    print(f"    {SERVER_URL}")
    print("=" * 55)
    try:
        s = requests.get(f"{SERVER_URL}/status", timeout=5).json()
        print(f"✅ {s['status']} | Brain: {s['brain_ready']} | Vision: {s['vision_ready']}")
        print(f"   Models: {s['models']}")
    except Exception:
        print("❌ Server not reachable. Check IP and port 7773 in AWS Security Group.")
        return

    speak("Namaste Sir! JARVIS online hai. Aap baat kar sakte hain.")
    mode = input("\nMode? [voice/text]: ").strip().lower()

    while True:
        if mode == "voice":
            user_input = listen_once()
            if not user_input: continue
            print(f"[You] {user_input}")
        else:
            user_input = input("\nYou: ").strip()
            if not user_input: continue

        if user_input.lower() in ["exit", "quit", "bye", "band karo"]:
            speak("Goodbye Sir."); break

        if any(w in user_input.lower() for w in ["screen", "dekho", "kya dikh", "analyze"]):
            desc = analyze_screen()
            reply = chat(f"User: {user_input}\nScreen mein yeh dikh raha hai: {desc}\nHelp karo.")
        else:
            reply = chat(user_input)

        print(f"\nJARVIS: {reply}\n")
        speak(reply)


if __name__ == "__main__":
    run()
