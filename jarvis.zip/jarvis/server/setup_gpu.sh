#!/bin/bash
set -e
echo "=== JARVIS GPU Server Setup — g4dn.2xlarge (T4 GPU) ==="

apt-get update -y
apt-get install -y python3 python3-pip python3-venv curl git screen htop ffmpeg

# ── NVIDIA Driver + CUDA (Ubuntu 22.04/24.04) ────────────────────────────────
echo "Installing NVIDIA drivers..."
apt-get install -y ubuntu-drivers-common
ubuntu-drivers autoinstall || true
# Fallback: manual CUDA toolkit
apt-get install -y nvidia-cuda-toolkit || true

# Verify GPU
nvidia-smi && echo "✅ GPU detected!" || echo "⚠️  Reboot may be needed for GPU driver"

# ── Install Ollama (auto-detects GPU) ────────────────────────────────────────
curl -fsSL https://ollama.com/install.sh | sh
systemctl enable ollama
systemctl start ollama
sleep 5

# ── Pull models (GPU mein fast hai!) ─────────────────────────────────────────
echo "Pulling llama3.1:8b (smart brain — GPU pe 1s response!)..."
ollama pull llama3.1:8b

echo "Pulling llava:7b (high quality vision)..."
ollama pull llava:7b

echo "Pulling llama3.2:1b (ultra-fast fallback)..."
ollama pull llama3.2:1b

# ── Python venv ───────────────────────────────────────────────────────────────
python3 -m venv /opt/jarvis-env
source /opt/jarvis-env/bin/activate
pip install --upgrade pip
pip install fastapi uvicorn gtts langdetect requests pillow python-multipart
pip install faster-whisper  # GPU-accelerated STT on server side!
pip install numpy soundfile

echo ""
echo "=== GPU Setup Complete! ==="
echo "GPU Stats:"; nvidia-smi --query-gpu=name,memory.total,memory.free --format=csv,noheader
echo ""
echo "Start JARVIS: cd /home/ubuntu/jarvis/server"
echo "  /opt/jarvis-env/bin/uvicorn jarvis_server.py:app --host 0.0.0.0 --port 7773"
