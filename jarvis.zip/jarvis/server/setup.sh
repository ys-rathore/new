#!/bin/bash
set -e
echo "=== JARVIS Fresh Setup for m7i-flex.large (Ubuntu) ==="

apt-get update -y
apt-get install -y python3 python3-pip python3-venv curl git screen htop

# AVX-512 check
echo "CPU AVX-512 support:"
grep -o 'avx512[^ ]*' /proc/cpuinfo | sort -u | head -3 || echo "Checking..."

# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh
systemctl enable ollama
systemctl start ollama
sleep 5

# Pull fastest model only (636MB)
echo "Pulling llama3.2:1b..."
ollama pull llama3.2:1b

# Python venv — using sudo to avoid permission issues
python3 -m venv /opt/jarvis-env

# FIX: always use sudo for system venv pip installs
sudo /opt/jarvis-env/bin/pip install --upgrade pip
sudo /opt/jarvis-env/bin/pip install \
    fastapi \
    uvicorn \
    gtts \
    langdetect \
    requests \
    pillow \
    python-multipart

echo ""
echo "=== Setup Complete! ==="
echo "Start JARVIS:"
echo "  cd /home/ubuntu/jarvis/server"
echo "  sudo /opt/jarvis-env/bin/uvicorn jarvis_server:app --host 0.0.0.0 --port 7773"
echo ""
echo "Or background:"
echo "  nohup sudo /opt/jarvis-env/bin/uvicorn jarvis_server:app --host 0.0.0.0 --port 7773 > nohup.out 2>&1 &"
