#!/bin/bash
set -e
echo "=== JARVIS Server Setup for Ubuntu AWS (port 7773) ==="

apt-get update -y
apt-get install -y python3 python3-pip python3-venv curl git screen htop

# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh
systemctl enable ollama
systemctl start ollama
sleep 5

# Pull models
echo "Pulling llama3.2..."
ollama pull llama3.2
echo "Pulling llava..."
ollama pull llava

# Python venv + ALL required deps (including python-multipart for file upload)
python3 -m venv /opt/jarvis-env
source /opt/jarvis-env/bin/activate
pip install --upgrade pip
pip install fastapi uvicorn gtts langdetect requests pillow python-multipart

echo ""
echo "=== Setup Complete! ==="
echo "Start JARVIS: cd /home/ubuntu/jarvis/server && /opt/jarvis-env/bin/uvicorn jarvis_server:app --host 0.0.0.0 --port 7773"
