#!/bin/bash
echo "=== JARVIS Full Server Wipe ==="

# Kill running JARVIS server
pkill -f uvicorn 2>/dev/null && echo "✅ Uvicorn stopped" || echo "ℹ️  Uvicorn was not running"
pkill -f jarvis_server 2>/dev/null || true

# Remove old jarvis files
rm -rf /home/ubuntu/jarvis
rm -rf /opt/jarvis-env
rm -f /home/ubuntu/JARVIS_complete.zip
rm -f /home/ubuntu/jarvis.zip
rm -f /tmp/nohup.out
rm -f /home/ubuntu/jarvis/server/nohup.out

# Remove old systemd service if exists
systemctl stop jarvis 2>/dev/null || true
systemctl disable jarvis 2>/dev/null || true
rm -f /etc/systemd/system/jarvis.service
systemctl daemon-reload 2>/dev/null || true

# Stop and reinstall Ollama cleanly (optional - comment out if you want to keep models)
# systemctl stop ollama
# rm -rf /usr/local/bin/ollama
# rm -rf /usr/share/ollama

echo ""
echo "=== Wipe Complete! ==="
echo "Now upload fresh jarvis.zip and run:"
echo "  unzip jarvis.zip"
echo "  cd jarvis/server"
echo "  sudo bash setup.sh"
