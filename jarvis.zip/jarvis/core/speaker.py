import os, tempfile, pygame
from gtts import gTTS
from langdetect import detect

def speak(text: str):
    try:
        lang = detect(text)
        tts_lang = "hi" if lang == "hi" else "en"
        tts = gTTS(text=text, lang=tts_lang, slow=False)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as fp:
            tmp_path = fp.name
        tts.save(tmp_path)
        pygame.mixer.init()
        pygame.mixer.music.load(tmp_path)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
        pygame.mixer.music.unload()
        os.remove(tmp_path)
    except Exception as e:
        print(f"[Speaker Error] {e}")
