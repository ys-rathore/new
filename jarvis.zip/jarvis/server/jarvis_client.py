"""
JARVIS PC Client v9.1 — Sarvam aditya voice + .wav aplay
Run: source ~/jarvis-env/bin/activate && python3 jarvis/server/jarvis_client.py
"""
import requests, os, tempfile, sys, re, io, threading, queue
import speech_recognition as sr

SERVER_URL = "http://13.42.152.207:7773"
API_KEY    = "jarvis-secret-2025"

_tts_queue   = queue.Queue()
_tts_running = True

def _play(path):
    ext = os.path.splitext(path)[1]
    if os.name == "nt":
        os.system("start /wait " + path)
    elif "darwin" in sys.platform:
        os.system("afplay " + path)
    elif ext == ".wav":
        os.system("aplay -q " + path + " 2>/dev/null || mpg123 -q " + path + " 2>/dev/null")
    else:
        os.system("mpg123 -q " + path + " 2>/dev/null")

def _tts_worker():
    while _tts_running:
        try:
            text = _tts_queue.get(timeout=0.5)
            if text is None:
                break
            _play_speak(text)
            _tts_queue.task_done()
        except queue.Empty:
            continue

def _play_speak(text):
    if not text.strip():
        return
    try:
        resp = requests.post(SERVER_URL + "/speak",
                             json={"text": text.strip(), "api_key": API_KEY}, timeout=20)
        ext = ".wav" if "wav" in resp.headers.get("content-type", "") else ".mp3"
        with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as f:
            f.write(resp.content)
            tmp = f.name
        _play(tmp)
        os.remove(tmp)
    except Exception as e:
        print("[Speaker] " + str(e))

_tts_thread = threading.Thread(target=_tts_worker, daemon=True)
_tts_thread.start()

def speak(text):
    if text.strip():
        _tts_queue.put(text)

def chat(message):
    print("\nJARVIS: ", end="", flush=True)
    buffer = ""
    full_reply = ""
    sent_end = re.compile(r"(?<=[.!?\n])\s*")
    try:
        with requests.post(SERVER_URL + "/chat/stream",
                           json={"message": message, "api_key": API_KEY},
                           stream=True, timeout=120) as resp:
            for chunk in resp.iter_content(chunk_size=None, decode_unicode=True):
                if chunk:
                    print(chunk, end="", flush=True)
                    buffer += chunk
                    full_reply += chunk
                    parts = sent_end.split(buffer)
                    if len(parts) > 1:
                        for sentence in parts[:-1]:
                            if sentence.strip():
                                speak(sentence)
                        buffer = parts[-1]
        if buffer.strip():
            speak(buffer)
        print()
        return full_reply
    except Exception as e:
        print("\n[Chat Error] " + str(e))
        return ""

def listen():
    try:
        import speech_recognition as sr
    except ImportError:
        print("Run: pip install SpeechRecognition pyaudio")
        return ""
    r = sr.Recognizer()
    r.energy_threshold = 300
    r.dynamic_energy_threshold = True
    try:
        with sr.Microphone() as source:
            print("\n🎙️  Bol rahe hain...")
            r.adjust_for_ambient_noise(source, duration=0.3)
            audio = r.listen(source, timeout=8, phrase_time_limit=15)
        text = r.recognize_google(audio, language="hi-IN")
        print("[Aapne kaha] " + text)
        return text
    except Exception as e:
        print("[Mic Error] " + str(e))
        return ""

def see_screen():
    try:
        from mss import MSS
        from PIL import Image
        with MSS() as sct:
            mon = sct.monitors[1] if len(sct.monitors) > 1 else sct.monitors[0]
            img = sct.grab(mon)
            pil = Image.frombytes("RGB", img.size, img.bgra, "raw", "BGRX")
            buf = io.BytesIO()
            pil.save(buf, format="PNG")
            buf.seek(0)
        resp = requests.post(SERVER_URL + "/vision",
                             data={"api_key": API_KEY},
                             files={"file": ("screen.png", buf, "image/png")}, timeout=60)
        return resp.json().get("description", "")
    except Exception as e:
        return "Screen error: " + str(e)

def main():
    print("=" * 55)
    print("      JARVIS — Aapka Personal AI Assistant")
    print("      Server: " + SERVER_URL)
    print("=" * 55)
    try:
        s = requests.get(SERVER_URL + "/status", timeout=5).json()
        print("Status : " + str(s.get("status")))
        print("Model  : " + str(s.get("active_model")))
        print("Vision : " + ("Yes" if s.get("vision") else "No"))
        print("TTS    : Sarvam aditya/bulbul:v3")
    except Exception:
        print("Server se connect nahi ho pa raha: " + SERVER_URL)
        return
    speak("Namaste Sir! JARVIS ready hai.")
    print("\nMode: [1] Text  [2] Voice")
    mode = input("Choose (1/2): ").strip()
    while True:
        try:
            if mode == "2":
                user_input = listen()
                if not user_input:
                    continue
            else:
                user_input = input("\nAap: ").strip()
                if not user_input:
                    continue
            if user_input.lower() in ["exit", "quit", "bye", "band karo", "alvida"]:
                speak("Alvida Sir.")
                _tts_queue.join()
                break
            if any(w in user_input.lower() for w in ["screen", "dekho", "kya dikh", "analyze", "kya chal"]):
                print("Screen dekh raha hoon...")
                desc = see_screen()
                chat("Meri screen pe abhi exactly yeh dikh raha hai: " + desc + ". User ka sawaal: " + user_input)
            else:
                chat(user_input)
        except KeyboardInterrupt:
            speak("Goodbye Sir.")
            _tts_queue.join()
            break

if __name__ == "__main__":
    main()