#!/bin/bash
# Run this on your AWS server to free disk space for llava pull
echo "=== Disk Usage Before ==="
df -h /

echo "\n=== Cleaning apt cache ==="
apt-get clean
apt-get autoremove -y

echo "\n=== Removing unused large packages ==="
apt-get remove --purge -y manpages-dev build-essential linux-libc-dev 2>/dev/null || true
apt-get autoremove -y

echo "\n=== Disk Usage After ==="
df -h /

echo "\n=== Now pull llava ==="
echo "Run: ollama pull llava"
