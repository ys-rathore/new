#!/usr/bin/env python3
"""
JARVIS AI Server — m7i-flex.large Optimized
Version: 8.0 (Clean)
Port: 7773
"""

import os, subprocess, base64, tempfile, json
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel
from typing import Optional, Iterator
import requests
from gtts import gTTS
from langdetect import detect

app = FastAPI(title="JARVIS AI Server", version="8.0")

API_KEY     = os.environ.get("JARVIS_API_KEY", "jarvis-secret-2025")
OLLAMA_URL  = "http://localhost:11434"
BRAIN       = "llama3.2:1b"   # fastest on CPU/AVX-512
VISION      = "llava"
HISTORY     = []

# AVX-512 optimized inference options
INFER_OPTS = {
    "num_predict": 80,
    "num_ctx":     512,
    "num_threads": 2,
    "temperature": 0.7,
    "top_p":       0.9,
}

SYSTEM = (
    "You are JARVIS — a brilliant AI assistant. "
    "Reply in the SAME language the user uses (Hindi or English). "
    "Be sharp, helpful and concise — max 2-3 sentences unless asked for detail."
)

def auth(key: str):
    if key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized — wrong API key")

def get_models():
    try:
        data = requests.get(f"{OLLAMA_URL}/api/tags", timeout=3).json()
        return [m["name"] for m in data.get("models", [])]
    except Exception:
        return []

def pick_model(requested=None):
    models = get_models()
    if requested and any(requested in m for m in models):
        return requested
    for prefer in ["llama3.2:1b", "llama3.2", "llama3"]:
        if any(prefer in m for m in models):
            return prefer
    return BRAIN


class ChatReq(BaseModel):
    message: str
    api_key: str
    model: Optional[str] = None
    history: bool = True

class RunReq(BaseModel):
    command: str
    api_key: str

class SpeakReq(BaseModel):
    text: str
    api_key: str
    lang: Optional[str] = None


@app.on_event("startup")
async def warmup():
    """Pre-warm model — eliminates first-request cold start delay."""
    try:
        model = pick_model()
        requests.post(f"{OLLAMA_URL}/api/generate",
                      json={"model": model, "prompt": "hi",
                            "stream": False, "options": {"num_predict": 1, "num_ctx": 64}},
                      timeout=60)
        print(f"✅ JARVIS warmed up — model: {model}")
    except Exception as e:
        print(f"⚠️  Warmup skipped: {e}")


# ── STATUS ────────────────────────────────────────────────────────────────────
@app.get("/status")
def status():
    models = get_models()
    return {
        "status":       "JARVIS ONLINE 🟢",
        "version":      "8.0",
        "active_model": pick_model(),
        "all_models":   models,
        "vision":       any("llava" in m for m in models),
        "port":         7773,
        "chat_turns":   len(HISTORY) // 2,
    }


# ── STREAMING CHAT (fastest — use this!) ──────────────────────────────────────
@app.post("/chat/stream")
def chat_stream(req: ChatReq):
    auth(req.api_key)
    HISTORY.append({"role": "user", "content": req.message})
    msgs = (HISTORY[-10:] if req.history else [{"role": "user", "content": req.message}])

    def stream() -> Iterator[str]:
        payload = {
            "model":   pick_model(req.model),
            "messages": [{"role": "system", "content": SYSTEM}] + msgs,
            "stream":  True,
            "options": INFER_OPTS,
        }
        full = ""
        with requests.post(f"{OLLAMA_URL}/api/chat",
                           json=payload, stream=True, timeout=120) as resp:
            for line in resp.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line)
                        token = chunk.get("message", {}).get("content", "")
                        if token:
                            full += token
                            yield token
                        if chunk.get("done"):
                            HISTORY.append({"role": "assistant", "content": full})
                    except Exception:
                        continue

    return StreamingResponse(stream(), media_type="text/plain")


# ── BLOCKING CHAT ─────────────────────────────────────────────────────────────
@app.post("/chat")
def chat(req: ChatReq):
    auth(req.api_key)
    HISTORY.append({"role": "user", "content": req.message})
    msgs = (HISTORY[-10:] if req.history else [{"role": "user", "content": req.message}])
    payload = {
        "model":    pick_model(req.model),
        "messages": [{"role": "system", "content": SYSTEM}] + msgs,
        "stream":   False,
        "options":  INFER_OPTS,
    }
    resp  = requests.post(f"{OLLAMA_URL}/api/chat", json=payload, timeout=120)
    reply = resp.json()["message"]["content"]
    HISTORY.append({"role": "assistant", "content": reply})
    return {"reply": reply, "model": pick_model(req.model)}


# ── VISION ────────────────────────────────────────────────────────────────────
@app.post("/vision")
async def vision(api_key: str = "", file: UploadFile = File(...),
                 question: str = "What do you see on this screen?"):
    auth(api_key)
    models = get_models()
    if not any("llava" in m for m in models):
        return {"description": "Vision model not loaded. Run: ollama pull llava", "mode": "unavailable"}
    b64 = base64.b64encode(await file.read()).decode()
    payload = {
        "model":    VISION,
        "messages": [{"role": "user", "content": question, "images": [b64]}],
        "stream":   False,
        "options":  {"num_predict": 120, "num_ctx": 1024, "num_threads": 2},
    }
    resp = requests.post(f"{OLLAMA_URL}/api/chat", json=payload, timeout=120)
    return {"description": resp.json()["message"]["content"], "mode": "llava"}


# ── TEXT TO SPEECH ────────────────────────────────────────────────────────────
@app.post("/speak")
def speak(req: SpeakReq):
    auth(req.api_key)
    lang = req.lang
    if not lang:
        try:
            d = detect(req.text)
            lang = "hi" if d in ["hi", "mr", "ne", "ur"] else "en"
        except Exception:
            lang = "en"
    tts = gTTS(text=req.text, lang=lang, slow=False)
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3", dir="/tmp")
    tts.save(tmp.name)
    return FileResponse(tmp.name, media_type="audio/mpeg", filename="jarvis.mp3")


# ── RUN COMMAND ───────────────────────────────────────────────────────────────
@app.post("/run")
def run_command(req: RunReq):
    auth(req.api_key)
    try:
        out = subprocess.run(req.command, shell=True,
                             capture_output=True, text=True, timeout=60)
        return {"stdout": out.stdout, "stderr": out.stderr, "code": out.returncode}
    except subprocess.TimeoutExpired:
        return {"stdout": "", "stderr": "Command timed out (60s)", "code": -1}


# ── CLEAR MEMORY ──────────────────────────────────────────────────────────────
@app.delete("/memory")
def clear(api_key: str):
    auth(api_key)
    HISTORY.clear()
    return {"status": "Memory cleared ✅"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("jarvis_server:app", host="0.0.0.0", port=7773, reload=False, workers=1)
