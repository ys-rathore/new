#!/usr/bin/env python3
"""
JARVIS Server v9.0 — Sarvam TTS + Fixed Vision
- /chat/stream  → streaming tokens
- /speak        → Sarvam AI TTS (Hindi/English, natural voice)
- /vision       → llava with anti-hallucination prompt
"""

import os, subprocess, base64, tempfile, json
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel
from typing import Optional, Iterator
import requests
from langdetect import detect

app = FastAPI(title="JARVIS Server", version="9.0")

API_KEY       = os.environ.get("JARVIS_API_KEY", "jarvis-secret-2025")
SARVAM_KEY    = os.environ.get("SARVAM_API_KEY", "sk_6ewy0jjj_6gqTDnmwJqNATA42m3loMiy1")
OLLAMA_BASE   = "http://localhost:11434"
BRAIN_MODEL   = "llama3.2:1b"
VISION_MODEL  = "llava"
HISTORY       = []

INFER_OPTS = {
    "num_predict": 80,
    "num_ctx":     512,
    "num_threads": 2,
    "temperature": 0.7,
    "top_p":       0.9,
}

SYSTEM = (
    "You are JARVIS — a brilliant AI assistant. "
    "Reply in the SAME language the user uses (Hindi or English). "
    "Be sharp, helpful and concise — max 2-3 sentences unless asked for detail."
)

# Anti-hallucination vision prompt
VISION_PROMPT = (
    "Look at this screenshot very carefully. "
    "Describe ONLY what you can actually see on screen right now. "
    "Do NOT guess, invent, or assume anything not visible. "
    "List: open apps, windows, text, icons visible. "
    "If unsure, say 'I cannot clearly see this'. Be precise."
)

def auth(key: str):
    if key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")

def get_models():
    try:
        return [m["name"] for m in requests.get(f"{OLLAMA_BASE}/api/tags", timeout=3).json().get("models", [])]
    except Exception:
        return []

def pick_model(requested=None):
    models = get_models()
    if requested and any(requested in m for m in models):
        return requested
    for prefer in ["llama3.2:1b", "llama3.2", "llama3"]:
        if any(prefer in m for m in models):
            return prefer
    return BRAIN_MODEL


class ChatReq(BaseModel):
    message: str
    api_key: str
    model: Optional[str] = None
    history: bool = True

class RunReq(BaseModel):
    command: str
    api_key: str

class SpeakReq(BaseModel):
    text: str
    api_key: str
    lang: Optional[str] = None


@app.on_event("startup")
async def warmup():
    try:
        model = pick_model()
        requests.post(f"{OLLAMA_BASE}/api/generate",
                      json={"model": model, "prompt": "hi",
                            "stream": False, "options": {"num_predict": 1, "num_ctx": 64}},
                      timeout=60)
        print(f"✅ Warmed up: {model}")
    except Exception as e:
        print(f"⚠️ Warmup skipped: {e}")


@app.get("/status")
def status():
    models = get_models()
    return {
        "status":       "JARVIS ONLINE 🟢",
        "version":      "9.0",
        "active_model": pick_model(),
        "all_models":   models,
        "vision":       any("llava" in m for m in models),
        "tts":          "Sarvam AI",
        "port":         7773,
        "chat_turns":   len(HISTORY) // 2,
    }


@app.post("/chat/stream")
def chat_stream(req: ChatReq):
    auth(req.api_key)
    HISTORY.append({"role": "user", "content": req.message})
    msgs = (HISTORY[-10:] if req.history else [{"role": "user", "content": req.message}])

    def stream() -> Iterator[str]:
        payload = {
            "model":    pick_model(req.model),
            "messages": [{"role": "system", "content": SYSTEM}] + msgs,
            "stream":   True,
            "options":  INFER_OPTS,
        }
        full = ""
        with requests.post(f"{OLLAMA_BASE}/api/chat",
                           json=payload, stream=True, timeout=120) as resp:
            for line in resp.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line)
                        token = chunk.get("message", {}).get("content", "")
                        if token:
                            full += token
                            yield token
                        if chunk.get("done"):
                            HISTORY.append({"role": "assistant", "content": full})
                    except Exception:
                        continue

    return StreamingResponse(stream(), media_type="text/plain")


@app.post("/chat")
def chat(req: ChatReq):
    auth(req.api_key)
    HISTORY.append({"role": "user", "content": req.message})
    msgs = (HISTORY[-10:] if req.history else [{"role": "user", "content": req.message}])
    payload = {
        "model":    pick_model(req.model),
        "messages": [{"role": "system", "content": SYSTEM}] + msgs,
        "stream":   False,
        "options":  INFER_OPTS,
    }
    resp  = requests.post(f"{OLLAMA_BASE}/api/chat", json=payload, timeout=120)
    reply = resp.json()["message"]["content"]
    HISTORY.append({"role": "assistant", "content": reply})
    return {"reply": reply, "model": pick_model(req.model)}


@app.post("/vision")
async def vision(api_key: str = "", file: UploadFile = File(...),
                 question: str = ""):
    auth(api_key)
    models = get_models()
    if not any("llava" in m for m in models):
        return {"description": "Vision model not loaded.", "mode": "unavailable"}

    # Combine anti-hallucination prompt with user question
    full_prompt = VISION_PROMPT
    if question:
        full_prompt += " User question: " + question

    b64 = base64.b64encode(await file.read()).decode()
    payload = {
        "model":    VISION_MODEL,
        "messages": [{"role": "user", "content": full_prompt, "images": [b64]}],
        "stream":   False,
        "options":  {"num_predict": 200, "num_ctx": 2048, "num_threads": 2},
    }
    resp = requests.post(f"{OLLAMA_BASE}/api/chat", json=payload, timeout=120)
    return {"description": resp.json()["message"]["content"], "mode": "llava"}


@app.post("/speak")
def speak(req: SpeakReq):
    """Sarvam AI TTS — aditya voice, REST API, Hindi + English."""
    auth(req.api_key)
    lang = req.lang
    if not lang:
        try:
            d = detect(req.text)
            lang = "hi" if d in ["hi", "mr", "ne", "ur"] else "en"
        except Exception:
            lang = "en"

    sarvam_lang = "hi-IN" if lang == "hi" else "en-IN"

    try:
        resp = requests.post(
            "https://api.sarvam.ai/text-to-speech",
            headers={
                "api-subscription-key": SARVAM_KEY,
                "Content-Type": "application/json"
            },
            json={
                "inputs":               [req.text[:500]],
                "target_language_code": sarvam_lang,
                "speaker":              "aditya",
                "model":                "bulbul:v3",
                "pace":                 1.1,
                "speech_sample_rate":   22050,
                "enable_preprocessing": True,
            },
            timeout=15
        )
        data = resp.json()
        audio_b64 = data.get("audios", [None])[0]
        if audio_b64:
            import base64 as b64mod
            audio_bytes = b64mod.b64decode(audio_b64)
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav", dir="/tmp")
            tmp.write(audio_bytes)
            tmp.close()
            return FileResponse(tmp.name, media_type="audio/wav", filename="jarvis.wav")
        print("Sarvam error: " + str(data.get("error", {}).get("message", "No audio"))[:100])
    except Exception as e:
        print("Sarvam TTS error: " + str(e))

    # Fallback to gTTS
    from gtts import gTTS
    tts = gTTS(text=req.text, lang=lang, slow=False)
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3", dir="/tmp")
    tts.save(tmp.name)
    return FileResponse(tmp.name, media_type="audio/mpeg", filename="jarvis.mp3")


@app.post("/run")
def run_command(req: RunReq):
    auth(req.api_key)
    try:
        out = subprocess.run(req.command, shell=True,
                             capture_output=True, text=True, timeout=60)
        return {"stdout": out.stdout, "stderr": out.stderr, "code": out.returncode}
    except subprocess.TimeoutExpired:
        return {"stdout": "", "stderr": "Timed out", "code": -1}


@app.delete("/memory")
def clear(api_key: str):
    auth(api_key)
    HISTORY.clear()
    return {"status": "Memory cleared ✅"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("jarvis_server:app", host="0.0.0.0", port=7773, reload=False, workers=1)
