#!/bin/bash
set -e
echo "=== JARVIS Server Setup for Ubuntu AWS (port 7773) ==="

apt-get update -y
apt-get install -y python3 python3-pip python3-venv curl git screen htop

# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh
systemctl enable ollama
systemctl start ollama
sleep 5

# Pull brain model (llama3.2 = 2GB, fits easily in 42GB free)
echo "Pulling llama3.2..."
ollama pull llama3.2

# Pull vision model (llava = 4.1GB, 42GB free — no problem!)
echo "Pulling llava (screen vision)..."
ollama pull llava

# Python venv + deps
python3 -m venv /opt/jarvis-env
source /opt/jarvis-env/bin/activate
pip install --upgrade pip
pip install fastapi uvicorn gtts langdetect requests pillow

echo ""
echo "=== Setup Complete! ==="
echo "Start JARVIS: cd /home/ubuntu/jarvis/server && /opt/jarvis-env/bin/uvicorn jarvis_server:app --host 0.0.0.0 --port 7773"
