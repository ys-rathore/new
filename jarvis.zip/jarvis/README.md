# 🤖 JARVIS — Your Personal AI Assistant

## Files
| File | Description |
|---|---|
| `wipe_server.sh` | **PEHLE CHALAAO** — purana sab kuch delete karta hai |
| `setup.sh` | Fresh install — Ollama + Python + sab dependencies |
| `jarvis_server.py` | JARVIS AI server (FastAPI) |
| `jarvis_client.py` | Apne PC pe chalao — voice/text se baat karo |

## Quick Start

### Step 1 — Purana sab delete karo
```bash
chmod +x wipe_server.sh && sudo bash wipe_server.sh
```

### Step 2 — Fresh install karo
```bash
chmod +x setup.sh && sudo bash setup.sh
```

### Step 3 — JARVIS start karo
```bash
nohup sudo /opt/jarvis-env/bin/uvicorn jarvis_server:app --host 0.0.0.0 --port 7773 > nohup.out 2>&1 &
```

### Step 4 — Test karo
```bash
curl http://127.0.0.1:7773/status
```

### Step 5 — PC pe client chalao
- `jarvis_client.py` mein apna server IP daalo
- `python jarvis_client.py`

## Issues Fixed in v8.0
- ✅ `sudo pip` permission error — fixed
- ✅ `python-multipart` auto-installed
- ✅ Cold start delay — model pre-warmed at startup
- ✅ Slow response — llama3.2:1b + AVX-512 + streaming
- ✅ TTS delay — sentence-by-sentence speak karta hai
