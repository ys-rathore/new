#!/bin/bash
set -e
echo "=== JARVIS Server Setup — Ubuntu AWS ==="
apt-get update -y
apt-get install -y python3 python3-pip python3-venv curl git htop

curl -fsSL https://ollama.com/install.sh | sh
systemctl enable ollama && systemctl start ollama
sleep 5

echo "Pulling llama3.2:1b..."
ollama pull llama3.2:1b
echo "Pulling llava..."
ollama pull llava

python3 -m venv /opt/jarvis-env
sudo /opt/jarvis-env/bin/pip install --upgrade pip
sudo /opt/jarvis-env/bin/pip install fastapi uvicorn gtts langdetect requests pillow python-multipart

echo ""
echo "=== Setup Complete! ==="
echo "Start: cd ~/jarvis-server && sudo /opt/jarvis-env/bin/uvicorn jarvis_server:app --host 0.0.0.0 --port 7773"
